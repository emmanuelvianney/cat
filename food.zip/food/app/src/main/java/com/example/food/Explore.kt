package com.example.food

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.recyclerview.widget.RecyclerView

class Explore : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: RecipeAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_explore2)
        val listViewRecipes: ListView = findViewById()
        val recipeTitles = arrayOf("Recipe 1", "Recipe 2", "Recipe 3")
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, recipeTitles)
        listViewRecipes.adapter = adapter

        // Set an item click listener to navigate to the Recipe Details page
        listViewRecipes.setOnItemClickListener { _, _, position, _ ->
            val selectedRecipeTitle = recipeTitles[position]
            val intent = Intent(this, RecipeDetailsActivity::class.java)
            intent.putExtra("recipeTitle", selectedRecipeTitle)
            startActivity(intent)
        }
    }

    class RecipeDetailsActivity {

    }
}
