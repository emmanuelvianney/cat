package com.example.food

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Details : AppCompatActivity() {
    private lateinit var recipe: Recipe
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        recipe = intent.getParcelableExtra("recipe")

        // Set the recipe title.
        val titleTextView = findViewById<TextView>(R.id.titleTextView)
        titleTextView.text = recipe.title

        // Set the meal type.
        val mealTypeTextView = findViewById<TextView>(R.id.mealTypeTextView)
        mealTypeTextView.text = recipe.mealType

        // Set the number of people it serves.
        val peopleServedTextView = findViewById<TextView>(R.id.peopleServedTextView)
        peopleServedTextView.text = recipe.peopleServed.toString()

        // Set the difficulty level.
        val difficultyLevelTextView = findViewById<TextView>(R.id.difficultyLevelTextView)
        difficultyLevelTextView.text = recipe.difficultyLevel

        // Set the ingredients.
        val ingredientsTextView = findViewById<TextView>(R.id.ingredientsTextView)
        ingredientsTextView.text = recipe.ingredients.joinToString("\n")

        // Set the preparation steps.
        val preparationStepsTextView = findViewById<TextView>(R.id.preparationStepsTextView)
        preparationStepsTextView.text = recipe.preparationSteps.joinToString("\n")
    }
}