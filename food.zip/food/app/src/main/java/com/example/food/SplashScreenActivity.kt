package com.example.food


import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.food.ui.theme.FoodTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.layout.width
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp



class SplashScreenActivity : AppCompatActivity() {
    private val splashDelayMillis: Long = 2000
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        setContent {
            FoodTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.color.background
                ) {
                    HeaderImage()
                }
            }
        }

        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this@SplashScreenActivity, MainActivity::class.java)
            startActivity(intent)
            finish() // Finish the splash activity so that the user cannot go back to it
        }, splashDelayMillis)
    }
}

@Composable
fun HeaderImage() {
    // Build first in order for the image to render
    Image(
        painter = painterResource(id = R.drawable.baseline_food_bank_24),
        contentDescription = null,
        //step6; add modifier to width of image
        modifier = Modifier.width(200.dp)
    )
}

@Preview(showBackground = true, widthDp = 390, heightDp = 800)
@Composable
fun DefaultPreview() {
    FoodTheme {
        HeaderImage()
    }
}